fun luasPersegi (panjang: Double, lebar: Double): Double {
    return (panjang * lebar)
}

fun main () {
    val luas = luasPersegi(5.0, 5.0)
    println(luas)
}




