fun main() {
    var nama:String? = null

    if (nama != null ) {
        println(nama)
    } else { println("Nama tidak tersedia") }

nama = "Reza Dwi Restiyan"
    if (nama != null ) {
        println(nama)
    } else { println("Nama tidak tersedia") }
}